/**
 * Copyright 2018 VMware
 * Copyright 2018 Ted Yin
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cassert>
#include <random>
#include <signal.h>
#include <sys/time.h>

#include "salticidae/type.h"
#include "salticidae/netaddr.h"
#include "salticidae/network.h"
#include "salticidae/util.h"

#include "hotstuff/util.h"
#include "hotstuff/type.h"
#include "hotstuff/client.h"

using salticidae::Config;

using hotstuff::ReplicaID;
using hotstuff::NetAddr;
using hotstuff::EventContext;
//using hotstuff::MsgReqCmd;
using hotstuff::MsgOrdering1ReqCmd;
using hotstuff::MsgOrdering2ReqCmd;
using hotstuff::MsgRespCmd;
using hotstuff::MsgOrdering1RespCmd;
using hotstuff::MsgOrdering2RespCmd;
using hotstuff::MsgConsensusRespClientCmd;
using hotstuff::CommandDummy;
using hotstuff::HotStuffError;
using hotstuff::uint256_t;
using hotstuff::opcode_t;
using hotstuff::command_t;

EventContext ec;
ReplicaID proposer;
size_t max_async_num;
int max_iter_num;
uint32_t cid;
uint32_t cnt = 0;
uint32_t nfaulty;

struct Request {
    command_t cmd;
    size_t confirmed;
    size_t ordering_rtt1;
    size_t ordering_rtt2;
    size_t ordering_rtt3;
    salticidae::ElapsedTime et;
    salticidae::ElapsedTime et_exec;
    //    std::vector<std::string> timestamps;
    std::vector<uint64_t> timestamps;
    Request(const command_t &cmd): cmd(cmd), confirmed(0), ordering_rtt1(0), ordering_rtt2(0), ordering_rtt3(0) { et.start(); et_exec.start(); }
};

int count_order, count_exec;
int BATCH_SIZE, STABLE_PERIOD;
int count_backoff, total_backoff;
struct timespec last_exec_resp_ts;
using Net = salticidae::MsgNetwork<opcode_t>;

std::unordered_map<ReplicaID, Net::conn_t> conns;
std::unordered_map<const uint256_t, Request> waiting, waiting_exec;
std::vector<NetAddr> replicas;
std::vector<std::pair<struct timeval, double>> elapsed, elapsed_exec;
Net mn(ec, Net::Config());

void connect_all() {
    for (size_t i = 0; i < replicas.size(); i++)
        conns.insert(std::make_pair(i, mn.connect_sync(replicas[i])));
}

bool try_send(bool check = true) {
    if ((!check || waiting.size() < max_async_num) && max_iter_num)
    {
        auto cmd = new CommandDummy(cid, cnt++);
        MsgOrdering1ReqCmd msg(*cmd);
        //for (auto &p: conns) mn.send_msg(msg, p.second);
        
        for (int i = 0; i < BATCH_SIZE; i++) {
            for (auto &p: conns) mn.send_msg(msg, p.second);
        }
#ifndef HOTSTUFF_ENABLE_BENCHMARK
        HOTSTUFF_LOG_INFO("send new cmd %.10s",
                            get_hex(cmd->get_hash()).c_str());
#endif
        waiting.insert(std::make_pair(
            cmd->get_hash(), Request(cmd)));
        if (max_iter_num > 0)
            max_iter_num--;
        return true;
    }
    return false;
}

void client_resp_cmd_handler(MsgRespCmd &&msg, const Net::conn_t &) {
    auto &fin = msg.fin;
    HOTSTUFF_LOG_DEBUG("got %s", std::string(msg.fin).c_str());
    const uint256_t &cmd_hash = fin.cmd_hash;
    auto it = waiting.find(cmd_hash);
    auto &et = it->second.et;
    if (it == waiting.end()) return;

    if (++it->second.confirmed <= nfaulty) return; // wait for f + 1 ack
    et.stop();

#ifndef HOTSTUFF_ENABLE_BENCHMARK
    HOTSTUFF_LOG_INFO("got %s, wall: %.3f, cpu: %.3f",
                        std::string(fin).c_str(),
                        et.elapsed_sec, et.cpu_elapsed_sec);
#else
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    elapsed.push_back(std::make_pair(tv, et.elapsed_sec));
#endif
    waiting.erase(it);
    while (try_send());
}

void client_ordering1_resp_cmd_handler(MsgOrdering1RespCmd &&msg, const Net::conn_t &) {
    //HOTSTUFF_LOG_DEBUG("got %s", std::string(msg.fin).c_str());
    const uint256_t &cmd_hash = msg.cmd_hash;
    auto it = waiting.find(cmd_hash);
    if (it == waiting.end()) return;
    auto &et = it->second.et;    

    //std::string t = std::string(get_hex10(msg.timestamp));
    it->second.timestamps.push_back(msg.timestamp_us);
    if (++it->second.ordering_rtt1 != nfaulty*2+1) return; // wait for 2f + 1 timestamps

    // pick the median timestamp, the f+1 th one
    std::sort(it->second.timestamps.begin(), it->second.timestamps.end());
    uint64_t median = it->second.timestamps[nfaulty + 1];
    
    // send the second rtt message of ordering phase
    // printf("here1\n");
    MsgOrdering2ReqCmd next_msg(cmd_hash, median);
    for (auto &p: conns) {
        mn.send_msg(next_msg, p.second);
    }
}

void client_ordering2_resp_cmd_handler(MsgOrdering2RespCmd &&msg, const Net::conn_t &) {
    //HOTSTUFF_LOG_DEBUG("got %s", std::string(msg.fin).c_str());
    const uint256_t &cmd_hash = msg.cmd_hash;
    auto it = waiting.find(cmd_hash);
    if (it == waiting.end()) return;
    auto &et = it->second.et;
    

    if (++it->second.ordering_rtt2 != nfaulty*2+1) return; // wait for 2f + 1 ack
    et.stop();

#ifndef HOTSTUFF_ENABLE_BENCHMARK
    HOTSTUFF_LOG_INFO("got %s, wall: %.3f, cpu: %.3f, timestamps: %s",
                        std::string(get_hex10(cmd_hash)).c_str(),
                      et.elapsed_sec, et.cpu_elapsed_sec),
                        std::string(get_hex10(msg.timestamp)).c_str();
#else
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    //elapsed.push_back(std::make_pair(tv, et.elapsed_sec));
    count_order++;
    for (int i = 0; i < BATCH_SIZE; i++)
        elapsed.push_back(std::make_pair(tv, et.elapsed_sec));

    // for debug
    //fprintf(stdout, "got %s, timestamps: %s\n", std::string(get_hex10(cmd_hash)).c_str(), std::string(get_hex10(msg.timestamp)).c_str());
#endif
    waiting_exec.insert(std::make_pair(it->first, it->second));
    waiting.erase(it);

    // slowdown if waiting too long for the consensus phase
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    uint64_t now_clock_us = now.tv_sec;
    now_clock_us *= 1000 * 1000;
    now_clock_us += now.tv_nsec/1000;

    uint64_t last_clock_us = last_exec_resp_ts.tv_sec;
    last_clock_us *= 1000 * 1000;
    last_clock_us += last_exec_resp_ts.tv_nsec / 1000;

    const int ONE_SEC = 1000000;
    if (last_clock_us == 0 || now_clock_us - last_clock_us < std::max(ONE_SEC * 5, STABLE_PERIOD * 30)) {
        // last consensus response less than 1sec ago
        count_backoff = 0;
        while (try_send());
    } else {
        // slowdown the speed of sending requests
        count_backoff++;
        total_backoff++;
        usleep(ONE_SEC * 3);
        // usleep(ONE_SEC * (1 << count_backoff));
        clock_gettime(CLOCK_MONOTONIC, &last_exec_resp_ts);
        while (try_send());
    }
}


void client_ordering_exec_resp_handler(MsgConsensusRespClientCmd &&msg, const Net::conn_t &) {
    clock_gettime(CLOCK_MONOTONIC, &last_exec_resp_ts);

    //HOTSTUFF_LOG_DEBUG("got %s", std::string(msg.fin).c_str());
    const uint256_t &cmd_hash = msg.cmd_hash;
    auto it = waiting_exec.find(cmd_hash);
    if (it == waiting_exec.end()) return;    
    auto &et_exec = it->second.et_exec;

    if (++it->second.ordering_rtt3 != 1) return; // wait for 1 exec ack
    et_exec.stop();

#ifndef HOTSTUFF_ENABLE_BENCHMARK
    // HOTSTUFF_LOG_INFO("executed %s, wall: %.3f, cpu: %.3f",
    //                     std::string(get_hex10(cmd_hash)).c_str(),
    //                   et.elapsed_sec, et.cpu_elapsed_sec)).c_str();
#else
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    //elapsed_exec.push_back(std::make_pair(tv, et_exec.elapsed_sec));
    count_exec++;
    for (int i = 0; i < BATCH_SIZE; i++)
        elapsed_exec.push_back(std::make_pair(tv, et_exec.elapsed_sec));

    // for debug
    //fprintf(stdout, "got %s, timestamps: %s\n", std::string(get_hex10(cmd_hash)).c_str(), "303030000");
#endif
    waiting_exec.erase(it);

}



std::pair<std::string, std::string> split_ip_port_cport(const std::string &s) {
    auto ret = salticidae::trim_all(salticidae::split(s, ";"));
    return std::make_pair(ret[0], ret[1]);
}

int main(int argc, char **argv) {
    Config config(argv[1]);
    std::string orderlogfile(argv[2]);
    std::string execlogfile(argv[3]);
    //Config config("hotstuff.conf");

    auto opt_blk_size = Config::OptValInt::create(1);
    auto opt_stable_period = Config::OptValInt::create(50);
    auto opt_idx = Config::OptValInt::create(0);
    auto opt_replicas = Config::OptValStrVec::create();
    auto opt_max_iter_num = Config::OptValInt::create(100);
    auto opt_max_async_num = Config::OptValInt::create(10);
    auto opt_max_cli_msg = Config::OptValInt::create(65536); // 64K by default
    auto opt_cid = Config::OptValInt::create(-1);

    auto shutdown = [&](int) { ec.stop(); };
    salticidae::SigEvent ev_sigint(ec, shutdown);
    salticidae::SigEvent ev_sigterm(ec, shutdown);
    ev_sigint.add(SIGINT);
    ev_sigterm.add(SIGTERM);

    //mn.reg_handler(client_resp_cmd_handler);
    mn.reg_handler(client_ordering1_resp_cmd_handler);
    mn.reg_handler(client_ordering2_resp_cmd_handler);
    mn.reg_handler(client_ordering_exec_resp_handler);
    mn.start();

    config.add_opt("block-size", opt_blk_size, Config::SET_VAL);
    config.add_opt("stable-period", opt_stable_period, Config::SET_VAL);
    config.add_opt("idx", opt_idx, Config::SET_VAL);
    config.add_opt("cid", opt_cid, Config::SET_VAL);
    config.add_opt("replica", opt_replicas, Config::APPEND);
    config.add_opt("iter", opt_max_iter_num, Config::SET_VAL);
    config.add_opt("max-async", opt_max_async_num, Config::SET_VAL);
    config.add_opt("max-cli-msg", opt_max_cli_msg, Config::SET_VAL, 'S', "the maximum client message size");
    config.parse(argc, argv);

    BATCH_SIZE = opt_blk_size->get();
    STABLE_PERIOD = opt_stable_period->get() * 1000;
    auto idx = opt_idx->get();
    max_iter_num = opt_max_iter_num->get();
    max_async_num = opt_max_async_num->get();
    std::vector<std::string> raw;
    for (const auto &s: opt_replicas->get())
    {
        auto res = salticidae::trim_all(salticidae::split(s, ","));
        if (res.size() < 1)
            throw HotStuffError("format error");
        raw.push_back(res[0]);
    }

    if (!(0 <= idx && (size_t)idx < raw.size() && raw.size() > 0))
        throw std::invalid_argument("out of range");
    cid = opt_cid->get() != -1 ? opt_cid->get() : idx;
    for (const auto &p: raw)
    {
        auto _p = split_ip_port_cport(p);
        size_t _;
        replicas.push_back(NetAddr(NetAddr(_p.first).ip, htons(stoi(_p.second, &_))));
    }

    nfaulty = (replicas.size() - 1) / 3;
    HOTSTUFF_LOG_INFO("nfaulty = %zu", nfaulty);
    connect_all();
    while (try_send());
    ec.dispatch();

#ifdef HOTSTUFF_ENABLE_BENCHMARK

    printf("client backoff %d times\n", total_backoff);
    printf("client write to order log file %s, %lu entries\n", orderlogfile.c_str(), elapsed.size());
    printf("client write to exec log file %s, %lu entries\n", execlogfile.c_str(), elapsed_exec.size());
    
    freopen(execlogfile.c_str(), "w", stdout);

    for (const auto &e: elapsed_exec)
    {
        char fmt[64];
        struct tm *tmp = localtime(&e.first.tv_sec);
        strftime(fmt, sizeof fmt, "%Y-%m-%d %H:%M:%S.%%06u [hotstuff info] %%.6f\n", tmp);
        fprintf(stdout, fmt, e.first.tv_usec, e.second);
    }

    
    freopen(orderlogfile.c_str(), "w", stdout);

    for (const auto &e: elapsed)
    {
        char fmt[64];
        struct tm *tmp = localtime(&e.first.tv_sec);
        strftime(fmt, sizeof fmt, "%Y-%m-%d %H:%M:%S.%%06u [hotstuff info] %%.6f\n", tmp);
        fprintf(stdout, fmt, e.first.tv_usec, e.second);
    }


    fclose(stdout);

#endif
    return 0;
}
