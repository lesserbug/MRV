file(REMOVE_RECURSE
  "CMakeFiles/hotstuff-tls-keygen.dir/link.d"
  "CMakeFiles/hotstuff-tls-keygen.dir/src/hotstuff_tls_keygen.cpp.o"
  "CMakeFiles/hotstuff-tls-keygen.dir/src/hotstuff_tls_keygen.cpp.o.d"
  "hotstuff-tls-keygen"
  "hotstuff-tls-keygen.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/hotstuff-tls-keygen.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
